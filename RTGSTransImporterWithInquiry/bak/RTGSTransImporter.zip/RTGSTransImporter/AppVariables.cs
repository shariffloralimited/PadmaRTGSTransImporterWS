using System;

namespace RTGS
{
    public static class AppVariables
    {
        public static string ConStr = RTGS.Global.AppVariable.ServerLogin;
    }
}