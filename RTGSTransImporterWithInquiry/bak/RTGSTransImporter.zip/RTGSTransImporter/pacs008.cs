﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace RTGSTransImporter
{

     public class pacs008
    {
            public string FileName = "";
            public string PacsID = "";
            public string DetectTime = "";
            public string FrBICFI = "";
            public string ToBICFI = "";
            public string BizMsgIdr = "";
            public string MsgDefIdr = "";
            public string BizSvc = "";
            public string CreDt = "";
            public string MsgId = "";
            public string CreDtTm = "";
            public string BatchBookingID = "";
            public string BtchBookg = "";
            public int NbOfTxs = 0;
            public string InstrId = "";
            public string EndToEndId = "";
            public string TxId = "";
            public string ClrChanl = "";
            public int SvcLvlPrtry = 0;
            public string LclInstrmPrtry = "";
            public string CtgyPurpPrtry = "";
            public string Ccy = "";
            public decimal TtlIntrBkSttlmAmt = 0;
            public decimal IntrBkSttlmAmt = 0;
            public string IntrBkSttlmDt = "";
            public string ChrgBr = "";
            public string InstgAgtBICFI = "";
            public string InstgAgtNm = "";
            public string InstgAgtBranchId = "";
            public string InstdAgtBICFI = "";
            public string InstdAgtNm = "";
            public string InstdAgtBranchId = "";
            public string DbtrNm = "";
            public string DbtrPstlAdr = "";
            public string DbtrStrtNm = "";
            public string DbtrTwnNm = "";
            public string DbtrAdrLine = "";
            public string DbtrCtry = "";
            public string DbtrAcctOthrId = "";
            public string DbtrAgtBICFI = "";
            public string DbtrAgtNm = "";
            public string DbtrAgtBranchId = "";
            public string DbtrAgtAcctOthrId = "";
            public string DbtrAgtAcctPrtry = "";
            public string CdtrAgtBICFI = "";
            public string CdtrAgtNm = "";
            public string CdtrAgtBranchId = "";
            public string CdtrAgtAcctOthrId = "30001707640";
            public string CdtrAgtAcctPrtry = "";
            public string CdtrNm = "";
            public string CdtrPstlAdr = "";
            public string CdtrStrtNm = "";
            public string CdtrTwnNm = "";
            public string CdtrAdrLine = "";
            public string CdtrCtry = "";
            public string CdtrAcctOthrId = "";
            public string CdtrAcctPrtry = "";
            public string InstrInf = "";
            public string Ustrd = "";
            public string PmntRsn = "";
            public string SendingDept = "";
            public string ReturnReason = "";
            public int DeptId = 0;
            public string Maker = "";
            public string MakeTime = "";
            public string MakerIP = "";
            public string Checker = "";
            public string CheckTime = "";
            public string CheckerIP = "";
            public string Admin = "";
            public string AdminTime = "";
            public string AdminIP = "";
            public string DeletedBy = "";
            public string DeleteTime = "";
            public string CBSResponse = "";
            public string CBSTime = "";
            public int StatusID = 0;
            public string FrBankBIC = "";
            public string FrBank = "";
            public string FrBranch = "";
            public string ToBranch = "";
            public string BrnchCD = "";
            public bool ChargeWaived = false;
            public string OutwardID = "";
    }
    }

